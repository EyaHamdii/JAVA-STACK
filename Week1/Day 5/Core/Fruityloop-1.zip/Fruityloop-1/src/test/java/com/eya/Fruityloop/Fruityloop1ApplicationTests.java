package com.eya.Fruityloop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fruityloop1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
